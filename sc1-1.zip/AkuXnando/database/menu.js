const menunya = (prefix) => {
	return`╭─❒ *LIST ALL FITUR BOT*
│ █▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀█
│ █░░╦─╦╔╗╦─╔╗╔╗╔╦╗╔╗░░█
│ █░░║║║╠─║─║─║║║║║╠─░░█
│ █░░╚╩╝╚╝╚╝╚╝╚╝╩─╩╚╝░░█
│ █▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄█
│◦➛ ⬣ 𝙁𝙄𝙏𝙐𝙍 𝙊𝙒𝙉𝙀𝙍 
│◦➛ ${prefix}off
│◦➛ ${prefix}isbaileys
│◦➛ ${prefix}banchat
│◦➛ ${prefix}unbanchat
│◦➛ ${prefix}listbc
│◦➛ ${prefix}setcmd
│◦➛ ${prefix}delcmd
│◦➛ ${prefix}listcmd
│◦➛ ${prefix}restart
│◦➛ ${prefix}antidelete on|off
│◦➛ ${prefix}autoketik on|off
│◦➛ ${prefix}autoread gc in / gc off
│◦➛ ${prefix}autovn on|off
│◦➛ ${prefix}anticall on|off
│◦➛ ${prefix}getcaption
│◦➛ ${prefix}bugkatalog
│◦➛ ${prefix}buggc id grup
│◦➛ ${prefix}bugpc *only pc*
│◦➛ ${prefix}troliv1
│◦➛ ${prefix}troliv2 *total*
│◦➛ ${prefix}okvirtex
│◦➛ ${prefix}on
│◦➛ ${prefix}status
│◦➛ ${prefix}setthumb
│◦➛ ${prefix}settarget
│◦➛ ${prefix}setfakeimg
│◦➛ ${prefix}setreply
│◦➛ ${prefix}hacked nama
│◦➛ ${prefix}setprefix
│◦➛ ${prefix}mode /public-self/
│◦➛ ${prefix}term <code>
│◦➛ ${prefix}eval <code>
│◦➛ ${prefix}colongsw reply
│ 
│   ⬣ 𝙁𝙄𝙏𝙐𝙍 𝙂𝙍𝙐𝙋 
│◦➛ ${prefix}grup 
│◦➛ ${prefix}promote 
│◦➛ ${prefix}demote 
│◦➛ ${prefix}setdesc
│◦➛ ${prefix}setname
│◦➛ ${prefix}nsfw 1/0
│◦➛ ${prefix}kick 
│◦➛ ${prefix}add 
│◦➛ ${prefix}getbio
│◦➛ ${prefix}getname 
│◦➛ ${prefix}reminder 
│◦➛ ${prefix}listonline
│◦➛ ${prefix}sider reply
│◦➛ ${prefix}antilink on|off
│◦➛ ${prefix}tod
│◦➛ ${prefix}tospam jumlah
│◦➛ ${prefix}antihidetag on|off
│◦➛ ${prefix}antiviewonce on|off
│◦➛ ${prefix}antivirtex on|off
│◦➛ ${prefix}autojoin on|off
│◦➛ ${prefix}kickarea
│
│   ⬣ 𝙁𝙄𝙏𝙐𝙍 𝙈𝘼𝙆𝙀𝙍 
│◦➛ ${prefix}sticker
│◦➛ ${prefix}swm author|packname
│◦➛ ${prefix}take author|packname
│◦➛ ${prefix}fdeface
│◦➛ ${prefix}attp teks
│◦➛ ${prefix}fancytext teks
│◦➛ ${prefix}emoji 
│◦➛ ${prefix}halloween teks
│◦➛ ${prefix}vampire teks
│◦➛ ${prefix}codetxt teks
│◦➛ ${prefix}googletxt
│◦➛ ${prefix}spiderman teks
│◦➛ ${prefix}express teks
│◦➛ ${prefix}maker2d2 teks
│◦➛ ${prefix}maker2d3 teks
│◦➛ ${prefix}maker2d4 teks
│◦➛ ${prefix}golden teks
│◦➛ ${prefix}flower teks
│◦➛ ${prefix}dance
│◦➛ ${prefix}wooden teks
│◦➛ ${prefix}burn
│◦➛ ${prefix}glow teks
│◦➛ ${prefix}summer teks
│◦➛ ${prefix}neon teks
│◦➛ ${prefix}coffeecup teks
│◦➛ ${prefix}coffeecup2 teks
│◦➛ ${prefix}battlefield teks|teks
│◦➛ ${prefix}googletxt2 teks
│◦➛ ${prefix}transformer teks
│◦➛ ${prefix}nulis teks
│◦➛ ${prefix}text3d teks
│◦➛ ${prefix}warrior teks
│ 
│    ⬣ 𝙁𝙄𝙏𝙐𝙍 𝘾𝙊𝙉𝙑𝙀𝙍𝙏 
│◦➛ ${prefix}tomp3
│◦➛ ${prefix}tomp4
│◦➛ ${prefix}toimg
│◦➛ ${prefix}slow
│◦➛ ${prefix}fast
│◦➛ ${prefix}reverse
│◦➛ ${prefix}tourl
│ 
│   ⬣ 𝙁𝙄𝙏𝙐𝙍 𝘿𝙊𝙒𝙉𝙇𝙊𝘼𝘿𝙀𝙍 
│◦➛ ${prefix}play query
│◦➛ ${prefix}ytmp4 link
│◦➛ ${prefix}ytmp3 link
│◦➛ ${prefix}video query
│◦➛ ${prefix}instagram link
│◦➛ ${prefix}twitter
│◦➛ ${prefix}facebook link
│◦➛ ${prefix}tiktokdl
│ 
│   ⬣ 𝙁𝙄𝙏𝙐𝙍 𝙏𝘼𝙂 
│◦➛ ${prefix}hidetag
│◦➛ ${prefix}kontag
│◦➛ ${prefix}sticktag
│◦➛ ${prefix}totag
│ 
│    ⬣ 𝙁𝙄𝙏𝙐𝙍 𝙐𝙋𝙎𝙒 
│◦➛ ${prefix}upswteks
│◦➛ ${prefix}upswlokasi
│◦➛ ${prefix}upswsticker
│◦➛ ${prefix}upswimage
│◦➛ ${prefix}upswvideo
│◦➛ ${prefix}upswgif
│
│    ⬣ 𝐋𝐈𝐒𝐓 𝐌𝐄𝐍𝐔
│◦➛ ${prefix}slot
│◦➛ ${prefix}limitgame
│◦➛ ${prefix}gelud @tag
│◦➛ ${prefix}tictactoe @tag
│◦➛ ${prefix}siapaaku
│◦➛ ${prefix}family100
│◦➛ ${prefix}kuismath
│◦➛ ${prefix}asahotak
│◦➛ ${prefix}tebaklirik
│◦➛ ${prefix}tebaklagu
│◦➛ ${prefix}tebakkata
│◦➛ ${prefix}susunkata
│◦➛ ${prefix}kimiakuis
│◦➛ ${prefix}caklontong
│◦➛ ${prefix}tebakjenaka
│◦➛ ${prefix}tebakanime
│◦➛ ${prefix}tebaktebakan
│◦➛ ${prefix}tebakgambar
│◦➛ ${prefix}tebakbendera
│◦➛ ${prefix}suit *batu/kertas/gunting*
│
│    ⬣ 𝙁𝙄𝙏𝙐𝙍 𝙁𝙐𝙉 
│◦➛ ${prefix}fitnah
│◦➛ ${prefix}fitnahpc
│◦➛ ${prefix}kontak 0|p
│◦➛ ${prefix}lolivid
│◦➛ ${prefix}suit
│◦➛ ${prefix}toxic
│◦➛ ${prefix}flock
│◦➛ ${prefix}pantun
│◦➛ ${prefix}dadu
│◦➛ ${prefix}asupan
│◦➛ ${prefix}viewonce
│◦➛ ${prefix}detikvn number
│◦➛ ${prefix}detikvideo number
│◦➛ ${prefix}hbd
│ 
│    ⬣ 𝙁𝙄𝙏𝙐𝙍 𝙉𝙎𝙁𝙒 
│◦➛ ${prefix}yuri
│◦➛ ${prefix}hentai
│◦➛ ${prefix}anal
│◦➛ ${prefix}eroneko
│◦➛ ${prefix}lesbian
│◦➛ ${prefix}kitsune
│◦➛ ${prefix}bj
│◦➛ ${prefix}pussy
│◦➛ ${prefix}wallpaper
│◦➛ ${prefix}neko2
│◦➛ ${prefix}baka
│◦➛ ${prefix}slap
│◦➛ ${prefix}poke
│◦➛ ${prefix}keta
│◦➛ ${prefix}awoo
│◦➛ ${prefix}blowjob
│◦➛ ${prefix}megumin
│◦➛ ${prefix}neko
│◦➛ ${prefix}trapnime
└──────[ GITHUB ]──────❒
│◦➛Script Ory :
│◦➛https://github.com/chiya-kun-bot-aq
│◦➛Notes : mendkng timdur:v
└──────────────────❒`
}
exports.menunya = menunya